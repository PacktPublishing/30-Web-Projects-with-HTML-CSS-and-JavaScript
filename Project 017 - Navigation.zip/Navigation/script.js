document.querySelector(".dots-btn").addEventListener("click", () => {
  document.querySelector(".container").classList.toggle("change");
});
