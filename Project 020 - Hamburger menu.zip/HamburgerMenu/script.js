document.querySelector(".hamburger-menu").addEventListener("click", () => {
  document.querySelector(".navigation").classList.toggle("change");
});
