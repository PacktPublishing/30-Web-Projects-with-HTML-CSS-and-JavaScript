const door = document.querySelector(".door");

door.addEventListener("click", () => {
  door.classList.toggle("change");
});
